'use client';

import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

export default function Home() {
  const [currentWord, setCurrentWord] = useState(0);
  const words = ['Landing Pages', 'Websites', 'Portfólios'];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentWord((prev) => (prev + 1) % words.length);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <main className="min-h-screen font-sans bg-zinc-900 text-zinc-100">
      <section className="flex flex-col items-center justify-center h-screen px-4 text-center">
        <motion.h1
          className="text-4xl md:text-6xl font-bold mb-4"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          Olá, eu sou Danilo
        </motion.h1>
        <motion.p
          className="text-lg md:text-2xl text-neutral-400 h-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
        >
          Eu crio {words[currentWord]}
        </motion.p>
      </section>

      <section className="px-6 py-24 max-w-4xl mx-auto">
        <motion.h2
          className="text-3xl font-semibold mb-6"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          Sobre Mim
        </motion.h2>
        <motion.p
          className="text-neutral-400 leading-relaxed"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 1 }}
          viewport={{ once: true }}
        >
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent
          libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum
          imperdiet.
        </motion.p>
      </section>

      <section className="px-6 py-24 bg-neutral-900 rounded-lg">
        <motion.h2
          className="text-3xl font-semibold mb-12 text-center"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: false, amount: 0.3 }}
        >
          Projetos
        </motion.h2>

        <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto place-items-center">
          {[1, 2].map((id) => (
            <motion.div
              key={id}
              className="bg-neutral-800 rounded-2xl p-6 shadow-xl flex gap-6 items-center max-w-md w-full"
              initial={{ opacity: 0, x: id === 1 ? -100 : 100 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: id * 0.4 }}
              viewport={{ once: false, amount: 0.3 }}
            >
              <div className="w-32 h-32 bg-cyan-500 rounded-lg flex-shrink-0" />
              <div>
                <h3 className="text-xl font-semibold mb-2 text-white">Projeto {id}</h3>
                <p className="text-neutral-300 text-sm">
                  Esta é uma breve descrição fictícia do projeto {id}, destacando funcionalidades,
                  ferramentas usadas e objetivos alcançados.
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="px-6 py-24 max-w-3xl mx-auto text-center">
        <motion.h2
          className="text-3xl font-semibold mb-6"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          Entre em Contato
        </motion.h2>
        <motion.p
          className="text-neutral-400 mb-4"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 1 }}
          viewport={{ once: true }}
        >
          Me chame no e-mail ficticio@email.com ou nas redes sociais para conversar sobre seu projeto.
        </motion.p>
        <motion.button
          className="bg-white text-neutral-900 font-semibold py-2 px-6 rounded-full hover:bg-neutral-300 transition"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          viewport={{ once: true }}
        >
          Fale comigo
        </motion.button>
      </section>
    </main>
  );
}